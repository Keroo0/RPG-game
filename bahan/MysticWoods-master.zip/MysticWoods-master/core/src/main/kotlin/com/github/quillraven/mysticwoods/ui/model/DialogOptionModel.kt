package com.github.quillraven.mysticwoods.ui.model

data class DialogOptionModel(
    val idx: Int,
    val text: String,
)