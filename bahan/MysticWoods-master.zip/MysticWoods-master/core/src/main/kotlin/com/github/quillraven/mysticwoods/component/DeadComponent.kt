package com.github.quillraven.mysticwoods.component

data class DeadComponent(
    var reviveTime: Float = 0f
)