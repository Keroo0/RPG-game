package com.github.quillraven.mysticwoods.component

import com.github.quillraven.fleks.Entity

class LootComponent {
    var interactEntity: Entity? = null
}