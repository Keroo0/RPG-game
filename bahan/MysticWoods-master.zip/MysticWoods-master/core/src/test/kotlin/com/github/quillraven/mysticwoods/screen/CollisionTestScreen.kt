package com.github.quillraven.mysticwoods.screen

class CollisionTestScreen : TestScreen("collision.tmx")