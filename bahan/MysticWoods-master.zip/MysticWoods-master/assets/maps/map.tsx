<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="map" tilewidth="16" tileheight="16" tilecount="512" columns="32">
 <image source="../graphics/map.png" width="512" height="256"/>
 <tile id="192">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="0" width="14" height="13"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="2" width="16" height="13"/>
  </objectgroup>
 </tile>
 <tile id="224">
  <objectgroup draworder="index" id="2">
   <object id="14" x="0" y="0" width="15" height="15"/>
  </objectgroup>
 </tile>
 <tile id="416">
  <objectgroup draworder="index" id="2">
   <object id="1" x="11.9375" y="12.0313" width="4.0625" height="3.96875"/>
  </objectgroup>
 </tile>
 <tile id="417">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="418">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="13.0313" width="2.0625" height="2.96875"/>
  </objectgroup>
 </tile>
 <tile id="426">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4.03125" y="7.9375" width="11.9688" height="8.0625"/>
  </objectgroup>
 </tile>
 <tile id="427">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="7.9375" width="10" height="8.0625"/>
  </objectgroup>
 </tile>
 <tile id="448">
  <objectgroup draworder="index" id="2">
   <object id="1" x="11.9688" y="0" width="4.03125" height="5.96875"/>
  </objectgroup>
 </tile>
 <tile id="449">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="9"/>
  </objectgroup>
 </tile>
 <tile id="450">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="4.0625" height="8.9375"/>
  </objectgroup>
 </tile>
 <tile id="454">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="-1.6087" width="16" height="16.6087"/>
  </objectgroup>
 </tile>
 <tile id="455">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="-1.65217" width="16" height="16.6522"/>
  </objectgroup>
 </tile>
 <tile id="456">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="0" width="10" height="15"/>
  </objectgroup>
 </tile>
 <tile id="457">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="10" height="15"/>
  </objectgroup>
 </tile>
 <tile id="458">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3.9375" y="0" width="12.0625" height="8"/>
  </objectgroup>
 </tile>
 <tile id="459">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="11.9375" height="7.9375"/>
  </objectgroup>
 </tile>
</tileset>
