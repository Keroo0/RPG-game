Dear user,
Thank you for downloading our free product from Boxpix Studio. We hope you enjoy using it!

Support discord: https://discord.gg/xe7raWPp6z

Terms and Conditions:
By downloading this product, you are agreeing to the Terms of Service.
It is prohibited to resell, share as your own, or take credit for this product.
As this is a free product, no support, guarantees, or updates are promised.
We cannot be held responsible if the product is lost, deleted, or does not work as expected.
The Terms of Service may change at any time without prior notice.